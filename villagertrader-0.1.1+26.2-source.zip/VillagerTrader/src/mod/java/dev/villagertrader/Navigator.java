package dev.villagertrader;

import java.util.List;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.phys.Vec3;

/**
 * Cautious key-driven navigator. Call only on the client thread, at START_CLIENT_TICK
 * before KeyboardInput.tick(). The owner must stop this on screens/world unload/pause.
 * Only forward and jump are ever synthesized; pitch and real inactive input are untouched.
 */
public final class Navigator {
    public enum Result { MOVING, ARRIVED, FAILED }

    private static final int MAX_REPATHS = 5;
    private static final int MAX_TOTAL_TICKS = 1_200;
    private static final long MAX_TOTAL_NANOS = 90_000_000_000L;
    private static final int MAX_STUCK_TICKS = 50;
    private static final int MAX_WAYPOINT_TICKS = 100;
    private static final double TARGET_REPATH_DISTANCE_SQUARED = 1.0;
    private static final double WAYPOINT_RADIUS = 0.10;
    private static final double SETTLED_SPEED = 0.025;
    private static final System.Logger LOGGER = System.getLogger(Navigator.class.getName());

    private final Minecraft mc;
    private ClientLevel level;
    private LocalPlayer player;
    private Villager target;
    private Pathfinder finder;
    private List<Pathfinder.Node> path = List.of();
    private Vec3 plannedTarget;
    private Vec3 searchStart;
    private KeyMapping ownedForward;
    private KeyMapping ownedJump;
    private Result result = Result.FAILED;
    private boolean active;
    private boolean jumpStarted;
    private int jumpTicks;
    private int pathIndex;
    private int ticks;
    private int retries;
    private int groundedWait;
    private int waypointTicks;
    private int noProgressTicks;
    private double bestWaypointDistance;
    private long startedAt;
    private int pathsCalculated;
    private int repaths;

    public Navigator(Minecraft mc) { this.mc = mc; }

    /** Starts a new bounded attempt; cumulative counters intentionally survive start/stop. */
    public void start(Villager villager) {
        requireClientThread();
        stop();
        if (villager == null || mc.level == null || mc.player == null) return;
        level = mc.level;
        player = mc.player;
        target = villager;
        active = true;
        result = Result.MOVING;
        ticks = 0;
        retries = 0;
        groundedWait = 0;
        startedAt = System.nanoTime();
    }

    public Result tick() {
        requireClientThread();
        if (!active) return result; // Inactive ticks NEVER touch any input binding.
        try {
            return tickActive();
        } catch (RuntimeException failure) {
            finish(Result.FAILED);
            LOGGER.log(System.Logger.Level.WARNING, "Villager navigation stopped after a world/input failure", failure);
            return Result.FAILED;
        }
    }

    /** Releases just the bindings which this instance actually changed to pressed. */
    public void stop() {
        requireClientThread();
        finish(Result.FAILED);
    }

    /** Lifetime search attempts begun, including searches which do not find a route. */
    public int pathsCalculated() { return pathsCalculated; }

    /** Lifetime retries begun; each start is separately limited to five retries. */
    public int repaths() { return repaths; }

    private Result tickActive() {
        if (mc.level != level || mc.player != player || !player.isAlive()
                || !target.isAlive() || target.isRemoved() || target.level() != level
                || level.getEntity(target.getId()) != target) return finish(Result.FAILED);
        if (mc.isPaused()) {
            releaseMovement();
            return Result.MOVING;
        }
        if (++ticks > MAX_TOTAL_TICKS || System.nanoTime() - startedAt > MAX_TOTAL_NANOS) return finish(Result.FAILED);
        if (unsupportedMovement() || manualMovement()) return finish(Result.FAILED);
        // No sprint packets/keys are synthesized. Stop an already-running sprint
        // during navigation, so jumps and corner braking use walking speed.
        if (player.isSprinting()) player.setSprinting(false);
        if (player.onGround() && Pathfinder.canInteract(level, player, target)) return finish(Result.ARRIVED);

        // Compare against the search's target snapshot, NOT the previous tick;
        // slow cumulative villager movement therefore also triggers a retry.
        if (plannedTarget != null && target.position().distanceToSqr(plannedTarget) >= TARGET_REPATH_DISTANCE_SQUARED) {
            return retry();
        }

        if (finder == null) {
            releaseMovement();
            // Do not invent a grounded node halfway through a fall or start a
            // search while residual velocity is carrying the player off its origin.
            if (!player.onGround() || horizontalSpeed() > SETTLED_SPEED) {
                return ++groundedWait > 40 ? finish(Result.FAILED) : Result.MOVING;
            }
            groundedWait = 0;
            plannedTarget = target.position();
            searchStart = player.position();
            pathsCalculated++;
            finder = new Pathfinder(level, player, target);
        }

        if (path.isEmpty()) {
            releaseMovement();
            if (!player.onGround() || player.position().distanceToSqr(searchStart) > 0.04) return retry();
            Pathfinder.Status status = finder.tick();
            if (status == Pathfinder.Status.FAILED) return finish(Result.FAILED);
            if (status == Pathfinder.Status.SEARCHING) return Result.MOVING;
            path = finder.path();
            pathIndex = 0; // Align to the actual start center; never cut its first corner.
            resetWaypoint();
            return Result.MOVING;
        }

        finder.refreshGeometry();
        Pathfinder.Node waypoint = path.get(pathIndex);
        Pathfinder.Node previous = pathIndex == 0 ? waypoint : path.get(pathIndex - 1);
        boolean clearHere = jumpStarted && waypoint.y() > previous.y()
            ? finder.clearJumpMotion(player.position(), player.position(), waypoint)
            : finder.clearAt(player.position());
        if (!finder.walkable(waypoint) || !clearHere
                || (pathIndex > 0 && !finder.canTransition(previous, waypoint))) return retry();
        if (!insideEdge(previous, waypoint)) return retry();

        double distance = horizontalDistance(waypoint.feet());
        double heightDifference = waypoint.y() - player.getY();
        if (distance <= WAYPOINT_RADIUS && Math.abs(heightDifference) <= 0.08 && player.onGround()) {
            // Settle at EVERY waypoint before taking another axis. This is
            // intentional: neither waypoint compression nor a wide arrival
            // radius may turn an L-shaped corridor into a diagonal shortcut.
            releaseMovement();
            if (++waypointTicks > MAX_WAYPOINT_TICKS) return retry();
            if (horizontalSpeed() <= SETTLED_SPEED) {
                if (pathIndex + 1 == path.size()) return retry(); // LOS/reach was checked above.
                pathIndex++;
                resetWaypoint();
            }
            return Result.MOVING;
        }

        double progressDistance = distance + Math.abs(heightDifference) * 0.5;
        if (progressDistance < bestWaypointDistance - 0.04) {
            bestWaypointDistance = progressDistance;
            noProgressTicks = 0;
        } else {
            noProgressTicks++;
        }
        if (++waypointTicks > MAX_WAYPOINT_TICKS || noProgressTicks > MAX_STUCK_TICKS) return retry();

        if (pathIndex == 0) {
            if (!player.onGround() || !finder.canAlign(player.position(), waypoint)) return retry();
            steer(waypoint.feet(), false);
            return Result.MOVING;
        }
        int dy = waypoint.y() - previous.y();
        if (dy > 0) return jump(previous, waypoint);
        setJump(false);
        if (dy == 0) {
            if (!player.onGround()) {
                // Unexpected auto-jump/knockback is not treated as permission to
                // jump blindly. Release movement and re-plan after landing.
                return retry();
            }
            if (Math.abs(heightDifference) > 0.08 || !finder.supportedFootprint(player.position())
                    || !finder.clearMotion(player.position(), waypoint.feet())) return retry();
        } else {
            // The planned drop already checks the whole horizontal departure
            // and vertical landing column. Also reject changed geometry along
            // the real player's remaining horizontal correction at this height.
            Vec3 horizontalGoal = new Vec3(waypoint.x() + 0.5, player.getY(), waypoint.z() + 0.5);
            if (!finder.clearMotion(player.position(), horizontalGoal)) return retry();
        }
        steer(waypoint.feet(), !player.onGround());
        return Result.MOVING;
    }

    private Result jump(Pathfinder.Node previous, Pathfinder.Node waypoint) {
        Vec3 feet = player.position();
        if (!jumpStarted) {
            if (!player.onGround() || horizontalDistance(previous.feet()) > 0.24
                    || Math.abs(feet.y - previous.y()) > 0.08
                    || !finder.clearMotion(feet, feet.add(0, 1.30, 0))) return retry();
            Vec3 approach = new Vec3(waypoint.x() + 0.5, feet.y, waypoint.z() + 0.5);
            if (!finder.clearJumpMotion(feet, approach, waypoint)) return retry();
            // A normal forward+jump must start on the same tick. Waiting for
            // feet to reach +1 wastes the acceleration needed to land on top;
            // vanilla collision safely stalls the body against this step face.
            steer(waypoint.feet(), false);
            setJump(true);
            jumpStarted = true;
            jumpTicks = 0;
            return Result.MOVING;
        }
        setJump(false); // Single pulse, never hold to auto-bounce on a landing.
        if (++jumpTicks > 35) return retry();
        if (player.onGround()) {
            if (Math.abs(player.getY() - waypoint.y()) < 0.08) {
                if (!finder.clearMotion(feet, waypoint.feet())) return retry();
                steer(waypoint.feet(), false);
                return Result.MOVING;
            }
            if (jumpTicks > 2) return retry();
            setForward(false);
            return Result.MOVING;
        }
        if (player.getDeltaMovement().y < 0 && feet.y < waypoint.y() - 0.08) return retry();
        Vec3 approach = new Vec3(waypoint.x() + 0.5, feet.y, waypoint.z() + 0.5);
        if (!finder.clearJumpMotion(feet, approach, waypoint)) return retry();
        steer(waypoint.feet(), true);
        return Result.MOVING;
    }

    private void steer(Vec3 destination, boolean airborne) {
        double dx = destination.x - player.getX();
        double dz = destination.z - player.getZ();
        double distance = Math.sqrt(dx * dx + dz * dz);
        if (distance < 0.001) {
            setForward(false);
            return;
        }
        Vec3 velocity = player.getDeltaMovement();
        double projectedSpeed = (velocity.x * dx + velocity.z * dz) / distance;
        // Releasing forward does not brake an airborne player quickly enough
        // over a two-block drop. Counter-steer with the SAME owned forward key
        // when required, rather than modifying velocity or seizing keyDown.
        double stoppingDistance = projectedSpeed > 0 ? projectedSpeed * projectedSpeed / 0.04 : 0;
        if (airborne && projectedSpeed > 0.025 && distance <= 0.07 + stoppingDistance) {
            player.setYRot((float) Math.toDegrees(Math.atan2(dx, -dz)));
            setForward(true);
            return;
        }
        // Movement only needs yaw; preserve the user's pitch throughout.
        player.setYRot((float) Math.toDegrees(Math.atan2(-dx, dz)));
        double brakingDistance = Math.max(0, projectedSpeed) * 1.25;
        setForward(distance > 0.06 + (airborne ? 0 : brakingDistance));
    }

    private boolean insideEdge(Pathfinder.Node from, Pathfinder.Node to) {
        Vec3 position = player.position();
        double margin = pathIndex == 0 ? 0.51 : 0.25;
        return position.x >= Math.min(from.x(), to.x()) + 0.5 - margin
            && position.x <= Math.max(from.x(), to.x()) + 0.5 + margin
            && position.z >= Math.min(from.z(), to.z()) + 0.5 - margin
            && position.z <= Math.max(from.z(), to.z()) + 0.5 + margin
            && position.y >= Math.min(from.y(), to.y()) - 0.1
            && position.y <= Math.max(from.y(), to.y()) + 1.3;
    }

    private boolean unsupportedMovement() {
        return player.isSpectator() || player.getAbilities().flying || player.isPassenger()
            || player.isSwimming() || player.isInLiquid() || player.isInPowderSnow
            || player.isFallFlying() || player.onClimbable() || player.isSleeping()
            || player.getPose() != Pose.STANDING;
    }

    private boolean manualMovement() {
        // Manual steering cancels rather than clearing the user's other keys.
        return mc.options.keyDown.isDown() || mc.options.keyLeft.isDown() || mc.options.keyRight.isDown()
            || mc.options.keyShift.isDown() || mc.options.keySprint.isDown()
            || (ownedForward == null && mc.options.keyUp.isDown())
            || (ownedJump == null && mc.options.keyJump.isDown());
    }

    private Result retry() {
        releaseMovement();
        if (retries >= MAX_REPATHS) return finish(Result.FAILED);
        retries++;
        repaths++;
        finder = null;
        path = List.of();
        plannedTarget = null;
        searchStart = null;
        groundedWait = 0;
        resetWaypoint();
        return Result.MOVING;
    }

    private void resetWaypoint() {
        jumpStarted = false;
        jumpTicks = 0;
        waypointTicks = 0;
        noProgressTicks = 0;
        bestWaypointDistance = Double.POSITIVE_INFINITY;
    }

    private Result finish(Result terminal) {
        releaseMovement();
        active = false;
        result = terminal;
        finder = null;
        path = List.of();
        plannedTarget = null;
        searchStart = null;
        target = null;
        player = null;
        level = null;
        return terminal;
    }

    private void setForward(boolean pressed) {
        if (pressed) {
            KeyMapping key = mc.options.keyUp;
            if (ownedForward == null && !key.isDown()) ownedForward = key;
            if (ownedForward != null) ownedForward.setDown(true);
        } else if (ownedForward != null) {
            ownedForward.setDown(false);
            ownedForward = null;
        }
    }

    private void setJump(boolean pressed) {
        if (pressed) {
            KeyMapping key = mc.options.keyJump;
            if (ownedJump == null && !key.isDown()) ownedJump = key;
            if (ownedJump != null) ownedJump.setDown(true);
        } else if (ownedJump != null) {
            ownedJump.setDown(false);
            ownedJump = null;
        }
    }

    private void releaseMovement() {
        setForward(false);
        setJump(false);
    }

    private double horizontalDistance(Vec3 point) {
        double dx = player.getX() - point.x;
        double dz = player.getZ() - point.z;
        return Math.sqrt(dx * dx + dz * dz);
    }

    private double horizontalSpeed() {
        Vec3 velocity = player.getDeltaMovement();
        return Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z);
    }

    private void requireClientThread() {
        if (!mc.isSameThread()) throw new IllegalStateException("Navigator must run on the Minecraft client thread");
    }
}

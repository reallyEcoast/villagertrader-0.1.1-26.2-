package dev.villagertrader;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import net.minecraft.network.chat.Component;

/** Menu suggestions from the original script, not a restriction on actual server offers. */
public final class TradeCatalog {
    public record Option(String id, String translationKey) {
        public Component label() {
            return Component.translatable(translationKey);
        }
    }

    public static final List<Option> MODES = List.of(
        new Option("sell", "villagertrader.mode.sell"),
        new Option("buy", "villagertrader.mode.buy")
    );

    public static final List<Option> PROFESSIONS = List.of(
        profession(Selection.ANY),
        profession("farmer"),
        profession("fisherman"),
        profession("fletcher"),
        profession("shepherd"),
        profession("librarian"),
        profession("cartographer"),
        profession("cleric"),
        profession("armorer"),
        profession("toolsmith"),
        profession("weaponsmith"),
        profession("butcher"),
        profession("leatherworker"),
        profession("mason")
    );

    public static final Map<String, List<Option>> SELL_ITEMS = Map.ofEntries(
        Map.entry("farmer", items("wheat", "potato", "carrot", "beetroot", "pumpkin", "melon")),
        Map.entry("fisherman", items("string", "coal", "cod", "salmon")),
        Map.entry("fletcher", items("stick", "flint", "string", "feather", "tripwire_hook")),
        Map.entry("shepherd", items("white_wool", "black_wool", "brown_wool", "gray_wool",
            "white_dye", "black_dye", "blue_dye", "brown_dye")),
        Map.entry("librarian", items("paper", "book", "ink_sac")),
        Map.entry("cartographer", items("paper", "glass_pane")),
        Map.entry("cleric", items("rotten_flesh", "gold_ingot", "rabbit_foot", "turtle_scute", "nether_wart")),
        Map.entry("armorer", items("coal", "iron_ingot", "lava_bucket", "diamond")),
        Map.entry("toolsmith", items("coal", "iron_ingot", "flint", "diamond")),
        Map.entry("weaponsmith", items("coal", "iron_ingot", "flint", "diamond")),
        Map.entry("butcher", items("chicken", "porkchop", "rabbit", "coal", "dried_kelp_block", "sweet_berries")),
        Map.entry("leatherworker", items("leather", "flint", "rabbit_hide", "turtle_scute")),
        Map.entry("mason", items("clay_ball", "stone", "granite", "diorite", "andesite", "quartz"))
    );

    public static final Map<String, List<Option>> BUY_ITEMS = Map.ofEntries(
        Map.entry("farmer", items("bread", "apple", "cookie", "pumpkin_pie", "cake", "golden_carrot",
            "glistering_melon_slice")),
        Map.entry("fisherman", items("cooked_cod", "cooked_salmon", "campfire", "fishing_rod")),
        Map.entry("fletcher", items("arrow", "bow", "crossbow", "tipped_arrow")),
        Map.entry("shepherd", items("shears", "white_wool", "white_carpet", "white_bed", "white_banner", "painting")),
        Map.entry("librarian", items("bookshelf", "lantern", "glass", "clock", "compass", "name_tag", "enchanted_book")),
        Map.entry("cartographer", items("map", "filled_map", "item_frame", "glass_pane", "white_banner")),
        Map.entry("cleric", items("redstone", "lapis_lazuli", "glowstone", "ender_pearl", "experience_bottle")),
        Map.entry("armorer", items("iron_helmet", "iron_chestplate", "iron_leggings", "iron_boots",
            "diamond_helmet", "diamond_chestplate", "diamond_leggings", "diamond_boots")),
        Map.entry("toolsmith", items("stone_axe", "stone_pickaxe", "stone_shovel", "stone_hoe", "iron_axe",
            "iron_pickaxe", "diamond_axe", "diamond_pickaxe", "diamond_shovel", "diamond_hoe")),
        Map.entry("weaponsmith", items("iron_axe", "iron_sword", "diamond_axe", "diamond_sword")),
        Map.entry("butcher", items("rabbit_stew", "cooked_porkchop", "cooked_chicken")),
        Map.entry("leatherworker", items("leather_helmet", "leather_chestplate", "leather_leggings", "leather_boots", "saddle")),
        Map.entry("mason", items("brick", "chiseled_stone_bricks", "dripstone_block", "quartz_block", "quartz_pillar"))
    );

    private TradeCatalog() {
    }

    /** The wildcard also accepts valid server-added offers absent from these suggestions. */
    public static List<Option> itemOptions(String profession, boolean buying) {
        List<Option> options = new ArrayList<>();
        options.add(new Option(Selection.ANY,
            buying ? "villagertrader.item.any_buy" : "villagertrader.item.any_sell"));
        // Match the script: "all professions" offers only the unrestricted item choice.
        if (!Selection.ANY.equals(profession)) {
            options.addAll((buying ? BUY_ITEMS : SELL_ITEMS).getOrDefault(profession, List.of()));
        }
        return List.copyOf(options);
    }

    public static Component professionLabel(String id) {
        return profession(id).label();
    }

    public static Component modeLabel(boolean buying) {
        return Component.translatable(buying ? "villagertrader.mode.buy" : "villagertrader.mode.sell");
    }

    public static Component itemLabel(Selection selection) {
        if (selection.anyItem()) {
            return Component.translatable(selection.buying()
                ? "villagertrader.item.any_buy" : "villagertrader.item.any_sell");
        }
        return itemOptions(selection.profession(), selection.buying()).stream()
            .filter(option -> option.id().equals(selection.itemId()))
            .findFirst()
            .map(Option::label)
            .orElseGet(() -> Component.literal(selection.itemId()));
    }

    private static Option profession(String id) {
        return new Option(id, "villagertrader.profession." + id);
    }

    private static List<Option> items(String... paths) {
        List<Option> result = new ArrayList<>(paths.length);
        for (String path : paths) {
            result.add(new Option("minecraft:" + path, "villagertrader.item." + path));
        }
        return List.copyOf(result);
    }
}

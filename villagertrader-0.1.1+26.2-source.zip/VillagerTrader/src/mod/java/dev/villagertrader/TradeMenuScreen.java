package dev.villagertrader;

import java.util.List;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** A non-blocking, resize-safe three-step menu. Selecting an item starts the engine. */
public final class TradeMenuScreen extends Screen {
    private enum Step {
        MODE, PROFESSION, ITEM
    }

    private static final int BUTTON_HEIGHT = 20;
    private static final int GAP = 6;
    private static final int ROW_HEIGHT = 25;
    private static final int GRID_TOP = 64;
    private static final int MAX_ROWS = 5;

    private final TraderEngine engine;
    private Step step = Step.MODE;
    private boolean buying;
    private String profession = Selection.ANY;
    private int page;
    private int pageCount = 1;
    private int pagerY;

    public TradeMenuScreen(TraderEngine engine) {
        super(Component.translatable("villagertrader.menu.title"));
        this.engine = engine;
    }

    @Override
    public Component getTitle() {
        return Component.translatable(switch (step) {
            case MODE -> "villagertrader.menu.mode";
            case PROFESSION -> "villagertrader.menu.profession";
            case ITEM -> "villagertrader.menu.item";
        });
    }

    @Override
    protected void init() {
        List<TradeCatalog.Option> options = options();
        int wantedColumns = step == Step.MODE ? 2 : 3;
        int minimumWidth = step == Step.MODE ? 190 : 120;
        int columns = Math.max(1, Math.min(wantedColumns, (width - 24 + GAP) / (minimumWidth + GAP)));
        columns = Math.min(columns, options.size());
        int rows = Math.max(1, Math.min(MAX_ROWS, (height - GRID_TOP - 82) / ROW_HEIGHT));
        int pageSize = columns * rows;
        pageCount = Math.max(1, (options.size() + pageSize - 1) / pageSize);
        page = Math.max(0, Math.min(page, pageCount - 1));

        int buttonWidth = Math.max(1, Math.min(step == Step.MODE ? 220 : 160,
            (width - 24 - GAP * (columns - 1)) / columns));
        int gridWidth = columns * buttonWidth + GAP * (columns - 1);
        int startX = (width - gridWidth) / 2;
        int first = page * pageSize;
        int count = Math.min(pageSize, options.size() - first);
        for (int index = 0; index < count; index++) {
            TradeCatalog.Option option = options.get(first + index);
            int x = startX + (index % columns) * (buttonWidth + GAP);
            int y = GRID_TOP + (index / columns) * ROW_HEIGHT;
            addRenderableWidget(Button.builder(option.label(), button -> choose(option))
                .bounds(x, y, buttonWidth, BUTTON_HEIGHT)
                .tooltip(Tooltip.create(option.label()))
                .build());
        }

        pagerY = height - 73;
        if (pageCount > 1) {
            int pagerWidth = Math.min(280, width - 24);
            int left = (width - pagerWidth) / 2;
            Button previous = addRenderableWidget(Button.builder(
                    Component.translatable("villagertrader.menu.previous"), button -> changePage(-1))
                .bounds(left, pagerY, 76, BUTTON_HEIGHT).build());
            previous.active = page > 0;
            Button next = addRenderableWidget(Button.builder(
                    Component.translatable("villagertrader.menu.next"), button -> changePage(1))
                .bounds(left + pagerWidth - 76, pagerY, 76, BUTTON_HEIGHT).build());
            next.active = page + 1 < pageCount;
        }

        int footerY = height - 45;
        if (step != Step.MODE) {
            addRenderableWidget(Button.builder(Component.translatable("villagertrader.menu.back"), button -> goBack())
                .bounds(width / 2 - 121, footerY, 76, BUTTON_HEIGHT).build());
        }
        addRenderableWidget(Button.builder(Component.translatable("villagertrader.menu.cancel"), button -> onClose())
            .bounds(step == Step.MODE ? width / 2 - 80 : width / 2 - 39, footerY, 160, BUTTON_HEIGHT).build());
    }

    private List<TradeCatalog.Option> options() {
        return switch (step) {
            case MODE -> TradeCatalog.MODES;
            case PROFESSION -> TradeCatalog.PROFESSIONS;
            case ITEM -> TradeCatalog.itemOptions(profession, buying);
        };
    }

    private void choose(TradeCatalog.Option option) {
        switch (step) {
            case MODE -> {
                buying = "buy".equals(option.id());
                step = Step.PROFESSION;
            }
            case PROFESSION -> {
                profession = option.id();
                step = Step.ITEM;
            }
            case ITEM -> {
                Selection selection = new Selection(buying, profession, option.id());
                // The engine must see the world rather than our menu on its first tick.
                minecraft.gui.setScreen(null);
                if (minecraft.level != null && minecraft.player != null) {
                    minecraft.player.sendSystemMessage(Component.translatable("villagertrader.message.selected",
                        TradeCatalog.professionLabel(profession), TradeCatalog.modeLabel(buying), option.label()));
                    engine.start(selection);
                }
                return;
            }
        }
        page = 0;
        rebuildWidgets();
    }

    private void changePage(int direction) {
        page = Math.max(0, Math.min(pageCount - 1, page + direction));
        rebuildWidgets();
    }

    private void goBack() {
        step = step == Step.ITEM ? Step.PROFESSION : Step.MODE;
        page = 0;
        rebuildWidgets();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        // Screen's extraction wrapper already draws the background before this method.
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
        graphics.centeredText(font, getTitle(), width / 2, 12, 0xFFFFFFFF);
        graphics.centeredText(font, Component.translatable("villagertrader.menu.step", step.ordinal() + 1, 3),
            width / 2, 28, 0xFFB8D9E8);
        Component summary = switch (step) {
            case MODE -> Component.translatable("villagertrader.menu.intro");
            case PROFESSION -> TradeCatalog.modeLabel(buying);
            case ITEM -> Component.translatable("villagertrader.menu.summary",
                TradeCatalog.professionLabel(profession), TradeCatalog.modeLabel(buying));
        };
        graphics.centeredText(font, font.plainSubstrByWidth(summary.getString(), Math.max(1, width - 24)),
            width / 2, 44, 0xFFCCCCCC);
        if (pageCount > 1) {
            graphics.centeredText(font, Component.translatable("villagertrader.menu.page", page + 1, pageCount),
                width / 2, pagerY + 6, 0xFFFFFFFF);
        }
        Component hint = Component.translatable(step == Step.ITEM
            ? "villagertrader.menu.item_hint" : "villagertrader.menu.cancel_hint");
        graphics.centeredText(font, font.plainSubstrByWidth(hint.getString(), Math.max(1, width - 16)),
            width / 2, height - 15, 0xFFAAAAAA);
    }

    @Override
    public void tick() {
        if (minecraft.level == null || minecraft.player == null) {
            minecraft.gui.setScreen(null);
        }
    }

    @Override
    public void onClose() {
        if (engine.isActive()) {
            engine.stop(Component.translatable("villagertrader.message.cancelled").getString());
        } else if (minecraft.player != null) {
            minecraft.player.sendSystemMessage(Component.translatable("villagertrader.message.cancelled"));
        }
        minecraft.gui.setScreen(null);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}

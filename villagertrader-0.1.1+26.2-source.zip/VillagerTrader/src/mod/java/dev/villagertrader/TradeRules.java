package dev.villagertrader;

/** Pure decision rules, kept independent of game state for regression tests. */
public final class TradeRules {
    private static final String EMERALD = "minecraft:emerald";

    private TradeRules() {}

    public static boolean matches(boolean buying, String selected, String costA, String costB, String output) {
        if (buying) {
            return !EMERALD.equals(output)
                && (EMERALD.equals(costA) || EMERALD.equals(costB))
                && ("any".equals(selected) || selected.equals(output));
        }
        return EMERALD.equals(output)
            && ("any".equals(selected) || selected.equals(costA) || selected.equals(costB));
    }

    public static boolean canPay(int onlyA, int onlyB, int shared, int needA, int needB) {
        if (onlyA < 0 || onlyB < 0 || shared < 0 || needA < 0 || needB < 0) return false;
        long deficit = (long) Math.max(0, needA - onlyA) + Math.max(0, needB - onlyB);
        return deficit <= shared;
    }

    public static long batchOutput(int loadedA, int loadedB, int costA, int costB,
                                   int remainingUses, int outputCount) {
        if (costA <= 0 || costB < 0 || outputCount <= 0 || remainingUses <= 0) return 0;
        int trades = Math.min(loadedA / costA, remainingUses);
        if (costB > 0) trades = Math.min(trades, loadedB / costB);
        return (long) Math.max(0, trades) * outputCount;
    }
}

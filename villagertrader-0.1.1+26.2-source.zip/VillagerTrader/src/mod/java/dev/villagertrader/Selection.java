package dev.villagertrader;

import java.util.Objects;

/** A menu selection. "any" is a wildcard, never a registry identifier. */
public record Selection(boolean buying, String profession, String itemId) {
    public static final String ANY = "any";

    public Selection {
        Objects.requireNonNull(profession, "profession");
        Objects.requireNonNull(itemId, "itemId");
        if (profession.isBlank() || itemId.isBlank()) {
            throw new IllegalArgumentException("Trade selection identifiers must not be blank");
        }
    }

    public boolean anyProfession() {
        return ANY.equals(profession);
    }

    public boolean anyItem() {
        return ANY.equals(itemId);
    }
}

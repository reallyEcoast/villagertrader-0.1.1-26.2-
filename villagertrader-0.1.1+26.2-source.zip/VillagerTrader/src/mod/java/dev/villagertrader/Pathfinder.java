package dev.villagertrader;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Main-client-thread, incremental A*. Nodes are centers of full-block floors.
 * No partial-height floors (slabs/stairs), climbing, swimming, door operation,
 * block editing, diagonal shortcuts, or unloaded-chunk queries are supported.
 */
public final class Pathfinder {
    public static final int MAX_NODES = 14_000;
    public static final int SEARCH_RADIUS = 32;
    public static final int MAX_DROP = 2;
    public static final double INTERACTION_RANGE = 2.8;
    private static final int MAX_SEARCH_TICKS = 200;
    private static final int NODES_PER_TICK = 160;
    private static final long NANOS_PER_TICK = 3_000_000L;
    private static final double EPSILON = 1.0E-5;
    private static final double JUMP_RISE = 1.30;
    private static final int[][] DIRECTIONS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    private static final int[] HEIGHTS = {0, 1, -1, -2};

    public enum Status { SEARCHING, FOUND, FAILED }

    public record Node(int x, int y, int z) {
        public Vec3 feet() { return new Vec3(x + 0.5, y, z + 0.5); }
    }

    private record QueueEntry(Node node, double cost, double estimate, long order) {}
    private record Cell(boolean danger, boolean forbidden, boolean support, List<AABB> boxes) {}

    private final ClientLevel level;
    private final LocalPlayer player;
    private final Node origin;
    private final Vec3 targetEye;
    private final Vec3 targetCenter;
    private final double eyeHeight;
    private final double halfWidth;
    private final double height;
    private final Map<Node, Cell> cells = new HashMap<>();
    private final Map<Node, Double> costs = new HashMap<>();
    private final Map<Node, Node> parents = new HashMap<>();
    private final Set<Node> closed = new HashSet<>();
    private final PriorityQueue<QueueEntry> open = new PriorityQueue<>(
        Comparator.comparingDouble(QueueEntry::estimate).thenComparingLong(QueueEntry::order));
    private Status status = Status.SEARCHING;
    private List<Node> path = List.of();
    private int expanded;
    private int ticks;
    private long sequence;

    public Pathfinder(ClientLevel level, LocalPlayer player, Villager target) {
        this.level = level;
        this.player = player;
        this.targetEye = target.getEyePosition();
        this.targetCenter = target.getBoundingBox().getCenter();
        this.eyeHeight = player.getEyeHeight(Pose.STANDING);
        this.halfWidth = Math.max(0.3, player.getBbWidth() / 2.0) + 0.02;
        this.height = Math.max(1.8, player.getBbHeight());
        this.origin = new Node(floor(player.getX()), (int) Math.round(player.getY()), floor(player.getZ()));
        // Never pretend the player is standing on an adjacent level (notably slabs).
        if (Math.abs(player.getY() - origin.y()) > 0.08 || !walkable(origin)
                || !canAlign(player.position(), origin)) {
            status = Status.FAILED;
            return;
        }
        costs.put(origin, 0.0);
        open.add(new QueueEntry(origin, 0.0, heuristic(origin), sequence++));
    }

    /** Does at most 160 queue pops / about 3 ms of work. No world access off-thread. */
    public Status tick() {
        if (status != Status.SEARCHING) return status;
        if (++ticks > MAX_SEARCH_TICKS) return fail();
        refreshGeometry();
        long deadline = System.nanoTime() + NANOS_PER_TICK;
        int work = 0;
        while (!open.isEmpty() && work++ < NODES_PER_TICK) {
            if (work > 1 && System.nanoTime() >= deadline) break;
            QueueEntry entry = open.remove();
            Node current = entry.node();
            if (closed.contains(current) || entry.cost() != costs.getOrDefault(current, Double.POSITIVE_INFINITY)) continue;
            if (!walkable(current)) continue; // World updates never make a stale floor safe.
            closed.add(current);
            expanded++;
            if (canInteractFrom(current.feet().add(0, eyeHeight, 0), targetEye, targetCenter)) {
                ArrayList<Node> result = new ArrayList<>();
                for (Node node = current; node != null; node = parents.get(node)) result.add(node);
                Collections.reverse(result);
                path = List.copyOf(result); // Keep every corner AND every intermediate node.
                status = Status.FOUND;
                return status;
            }
            if (expanded >= MAX_NODES) return fail();
            for (int[] direction : DIRECTIONS) {
                for (int dy : HEIGHTS) {
                    Node next = new Node(current.x() + direction[0], current.y() + dy, current.z() + direction[1]);
                    if (!inBounds(next) || !walkable(next) || !canTransition(current, next)) continue;
                    if (!closed.contains(next)) {
                        double cost = entry.cost() + 1.0 + (dy > 0 ? 0.45 : -dy * 0.2);
                        if (cost < costs.getOrDefault(next, Double.POSITIVE_INFINITY)) {
                            // Bound discovered nodes as well as expanded nodes/memory.
                            if (!costs.containsKey(next) && costs.size() >= MAX_NODES) return fail();
                            costs.put(next, cost);
                            parents.put(next, current);
                            open.add(new QueueEntry(next, cost, cost + heuristic(next), sequence++));
                        }
                    }
                    break; // Prefer level, then a jump, then the smallest safe drop.
                }
            }
        }
        return open.isEmpty() ? fail() : status;
    }

    public List<Node> path() { return path; }

    /** Clear per-tick caches before checking a live route against changed blocks. */
    public void refreshGeometry() { cells.clear(); }

    public boolean walkable(Node node) {
        Cell floor = cell(node.x(), node.y() - 1, node.z());
        return floor != null && floor.support() && clear(body(node.feet()));
    }

    public boolean canAlign(Vec3 from, Node to) {
        Vec3 center = to.feet();
        return Math.abs(from.y - center.y) <= 0.08
            && Math.abs(from.x - center.x) <= 0.51 && Math.abs(from.z - center.z) <= 0.51
            && supportedFootprint(from) && clear(body(from).minmax(body(center)));
    }

    /** A whole-body sweep, not only destination feet/head or the falling feet column. */
    public boolean canTransition(Node from, Node to) {
        int dy = to.y() - from.y();
        if (Math.abs(from.x() - to.x()) + Math.abs(from.z() - to.z()) != 1 || dy > 1 || dy < -MAX_DROP) return false;
        if (!walkable(from) || !walkable(to)) return false;
        Vec3 a = from.feet();
        Vec3 b = to.feet();
        if (dy == 0) return clear(body(a).minmax(body(b)));
        if (dy > 0) {
            // Lift on the departure side; cross only above the step's top. Check
            // both sides all the way to a normal jump's apex, including headroom.
            Vec3 highA = a.add(0, JUMP_RISE, 0);
            Vec3 highB = new Vec3(b.x, highA.y, b.z);
            Vec3 crossingA = new Vec3(a.x, b.y, a.z);
            return clear(body(a).minmax(body(highA)))
                && clear(body(crossingA).minmax(body(highB)))
                && clear(body(b).minmax(body(highB)));
        }
        // Leave horizontally at the old height, then sweep the ENTIRE landing
        // column from the old head height down to the new feet. A low overhang,
        // an intermediate fence, or fluid anywhere in that volume rejects it.
        Vec3 departure = new Vec3(b.x, a.y, b.z);
        return clear(body(a).minmax(body(departure)))
            && clear(body(departure).minmax(body(b)));
    }

    /** Live safety check for small corrections while traversing an accepted edge. */
    public boolean clearMotion(Vec3 from, Vec3 to) { return clear(body(from).minmax(body(to))); }

    public boolean clearAt(Vec3 feet) { return clear(body(feet)); }

    /**
     * During an ordinary step jump the player's front touches the step's face
     * before clearing its top. Only that one validated, full-block support may
     * intersect this sweep; vanilla collision still resolves the contact.
     */
    public boolean clearJumpMotion(Vec3 from, Vec3 to, Node landing) {
        Node step = new Node(landing.x(), landing.y() - 1, landing.z());
        Cell support = cell(step.x(), step.y(), step.z());
        return support != null && support.support() && clear(body(from).minmax(body(to)), step);
    }

    public boolean supportedFootprint(Vec3 feet) {
        int y = (int) Math.round(feet.y);
        if (Math.abs(feet.y - y) > 0.08) return false;
        for (int x = floor(feet.x - halfWidth + EPSILON); x <= floor(feet.x + halfWidth - EPSILON); x++) {
            for (int z = floor(feet.z - halfWidth + EPSILON); z <= floor(feet.z + halfWidth - EPSILON); z++) {
                Cell support = cell(x, y - 1, z);
                if (support == null || !support.support()) return false;
            }
        }
        return true;
    }

    /** Current-position check uses exactly the same reach and occlusion rules as goals. */
    public static boolean canInteract(ClientLevel level, LocalPlayer player, Villager target) {
        Vec3 eye = player.getEyePosition();
        return visibleWithinReach(level, player, eye, target.getEyePosition())
            || visibleWithinReach(level, player, eye, target.getBoundingBox().getCenter());
    }

    private boolean canInteractFrom(Vec3 eye, Vec3 targetEye, Vec3 targetCenter) {
        return visibleWithinReach(level, player, eye, targetEye)
            || visibleWithinReach(level, player, eye, targetCenter);
    }

    private static boolean visibleWithinReach(ClientLevel level, LocalPlayer player, Vec3 eye, Vec3 point) {
        if (eye.distanceToSqr(point) > INTERACTION_RANGE * INTERACTION_RANGE) return false;
        // OUTLINE matches normal targeting more conservatively than COLLIDER
        // (e.g. glass, doors, and thin trading-hall partitions must block reach).
        return level.clip(new ClipContext(eye, point, ClipContext.Block.OUTLINE,
            ClipContext.Fluid.ANY, CollisionContext.withPosition(player, eye.y - player.getEyeHeight(Pose.STANDING))))
            .getType() == HitResult.Type.MISS;
    }

    private boolean inBounds(Node node) {
        int dx = node.x() - origin.x();
        int dz = node.z() - origin.z();
        return dx * dx + dz * dz <= SEARCH_RADIUS * SEARCH_RADIUS
            && Math.abs(node.y() - origin.y()) <= 6;
    }

    private double heuristic(Node node) {
        Vec3 eye = node.feet().add(0, eyeHeight, 0);
        double dx = eye.x - targetCenter.x;
        double dz = eye.z - targetCenter.z;
        // A lower bound to either eye/center reach; no vertical overestimate.
        return Math.max(0, Math.sqrt(dx * dx + dz * dz) - INTERACTION_RANGE);
    }

    private AABB body(Vec3 feet) {
        return new AABB(feet.x - halfWidth, feet.y + EPSILON, feet.z - halfWidth,
            feet.x + halfWidth, feet.y + height - EPSILON, feet.z + halfWidth);
    }

    private boolean clear(AABB box) { return clear(box, null); }

    private boolean clear(AABB box, Node permittedStep) {
        if (!level.getWorldBorder().isWithinBounds(box)) return false;
        int minX = floor(box.minX), maxX = floor(box.maxX - EPSILON);
        int minY = floor(box.minY), maxY = floor(box.maxY - EPSILON);
        int minZ = floor(box.minZ), maxZ = floor(box.maxZ - EPSILON);
        // Include neighboring blocks: fences/walls extend outside their unit
        // block, and hazardous/liquid neighbors are deliberately given a berth.
        for (int x = minX - 1; x <= maxX + 1; x++) {
            for (int z = minZ - 1; z <= maxZ + 1; z++) {
                for (int y = minY - 1; y <= maxY + 1; y++) {
                    Cell cell = cell(x, y, z);
                    if (cell == null) return false;
                    if (cell.danger()) return false;
                    boolean overlapsCell = box.intersects(x, y, z, x + 1, y + 1, z + 1);
                    if (cell.forbidden() && overlapsCell) return false;
                    if (permittedStep != null && x == permittedStep.x() && y == permittedStep.y()
                            && z == permittedStep.z() && cell.support()) continue;
                    for (AABB collision : cell.boxes()) {
                        if (box.intersects(collision)) return false;
                    }
                }
            }
        }
        return true;
    }

    private Cell cell(int x, int y, int z) {
        Node key = new Node(x, y, z);
        if (cells.containsKey(key)) return cells.get(key);
        BlockPos pos = new BlockPos(x, y, z);
        if (!level.isInsideBuildHeight(pos) || !level.hasChunk(x >> 4, z >> 4)) {
            cells.put(key, null);
            return null;
        }
        BlockState state = level.getBlockState(pos);
        boolean danger = !state.getFluidState().isEmpty() || state.is(BlockTags.FIRE)
            || state.is(BlockTags.CAMPFIRES) || state.is(Blocks.CACTUS)
            || state.is(Blocks.MAGMA_BLOCK) || state.is(Blocks.SWEET_BERRY_BUSH)
            || state.is(Blocks.WITHER_ROSE) || state.is(Blocks.POWDER_SNOW)
            || state.is(Blocks.POINTED_DRIPSTONE) || state.is(BlockTags.PORTALS)
            || state.is(Blocks.END_GATEWAY) || state.is(Blocks.MOVING_PISTON);
        boolean forbidden = danger || state.is(BlockTags.FENCES) || state.is(BlockTags.WALLS)
            || state.is(BlockTags.FENCE_GATES) || state.is(BlockTags.CLIMBABLE)
            || state.is(BlockTags.TRAPDOORS) || state.is(Blocks.COBWEB)
            || state.is(Blocks.SCAFFOLDING);
        boolean badFloor = forbidden || state.is(BlockTags.ICE) || state.is(Blocks.SLIME_BLOCK)
            || state.is(Blocks.HONEY_BLOCK);
        VoxelShape shape = state.getCollisionShape(level, pos, CollisionContext.empty());
        boolean support = !badFloor && state.isCollisionShapeFullBlock(level, pos);
        List<AABB> boxes;
        if (shape.isEmpty()) {
            boxes = List.of();
        } else {
            ArrayList<AABB> moved = new ArrayList<>();
            for (AABB bounds : shape.toAabbs()) moved.add(bounds.move(pos));
            boxes = List.copyOf(moved);
        }
        Cell result = new Cell(danger, forbidden, support, boxes);
        cells.put(key, result);
        return result;
    }

    private Status fail() {
        status = Status.FAILED;
        open.clear();
        return status;
    }

    private static int floor(double value) { return (int) Math.floor(value); }
}

package dev.villagertrader;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import net.minecraft.network.HashedStack;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.MerchantScreen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundSelectTradePacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.MerchantMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** All reads and actions run on the client thread. No blocking sleeps or worker world access. */
public final class TraderEngine {
    private static final Logger LOG = LoggerFactory.getLogger("VillagerTrader");
    private static final double RADIUS = 20.0;
    private static final int GUI_TIMEOUT = 100;
    private static final int SYNC_TIMEOUT = 100;
    private static final int ACTION_DELAY = 4;
    private enum State { IDLE, FIND, WALK, OPENING, SCAN, SELECTING, VERIFY, COOLDOWN, PAUSED }

    private final Minecraft mc;
    private final Navigator navigator;
    private final Set<UUID> visited = new HashSet<>();
    private final Set<String> missing = new HashSet<>();
    private State state = State.IDLE;
    private Selection selection;
    private ClientLevel world;
    private Vec3 origin;
    private Villager target;
    private MerchantMenu ownedMenu;
    private int delay;
    private int waited;
    private int offerIndex;
    private int pass;
    private int batches;
    private int villagersChecked;
    private int soldOut;
    private int matchingOffers;
    private long trades;
    private long outputs;
    private long passTrades;
    private String pauseReason = "";
    private boolean full;
    private int beforeOutput;
    private int beforeSelectState;
    private int beforeClickState;
    private int beforeUses;
    private int stableOutput;
    private int stableTicks;
    private long batchLimit;
    private ItemStack expectedOutput = ItemStack.EMPTY;
    private int outputPerTrade;

    public TraderEngine(Minecraft mc) {
        this.mc = mc;
        this.navigator = new Navigator(mc);
    }

    public boolean isActive() { return state != State.IDLE; }

    public String status() {
        if (state == State.IDLE) return "已停止";
        if (state == State.PAUSED) return "已暫停：" + pauseReason;
        return "執行中 | 村民 " + villagersChecked + " | 交易 " + trades + " | 產物 " + outputs;
    }

    public void start(Selection selected) {
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;
        if (isActive()) stop("重新開始");
        if (mc.gui.screen() != null || mc.player.containerMenu != mc.player.inventoryMenu) {
            chat("請先關閉其他選單再開始。");
            return;
        }
        selection = selected;
        world = mc.level;
        origin = mc.player.position();
        villagersChecked = 0;
        trades = outputs = 0;
        resetRound();
        state = State.FIND;
        chat("開始：" + (selected.buying() ? "購買" : "出售") + " | " + selected.profession()
            + " | " + selected.itemId() + "。搜尋起點周圍 20 格。");
        chat("只使用背包物品，不會存取箱子、挖掘或放置方塊。暫停／停止鍵可在控制設定更改。");
    }

    public void togglePause() {
        if (!isActive()) return;
        if (state != State.PAUSED) {
            pause("手動暫停");
            return;
        }
        if (mc.level != world || mc.player == null) {
            stop("世界已變更");
            return;
        }
        if (mc.gui.screen() != null || mc.player.containerMenu != mc.player.inventoryMenu) {
            chat("請先關閉其他介面，再按暫停／繼續鍵。");
            return;
        }
        resetRound();
        state = State.COOLDOWN;
        delay = 10;
        chat("繼續：重新檢查材料與村民交易。");
    }

    public void stop(String reason) {
        boolean active = isActive();
        navigator.stop();
        closeOwnedMenu();
        state = State.IDLE;
        target = null;
        if (active) chat("已停止：" + reason + " | 檢查村民 " + villagersChecked + " | 交易約 " + trades + " | 產物 " + outputs);
    }

    private void pause(String reason) {
        navigator.stop();
        closeOwnedMenu();
        target = null;
        state = State.PAUSED;
        pauseReason = reason;
        chat(reason + "，已暫停；處理後按暫停／繼續鍵重試，或按停止鍵結束。");
        overlay(status());
    }

    private void resetRound() {
        visited.clear();
        missing.clear();
        soldOut = matchingOffers = pass = 0;
        passTrades = 0;
        full = false;
        delay = waited = 0;
    }

    public void tick() {
        if (!isActive()) return;
        try {
            if (mc.player == null || mc.level != world || mc.gameMode == null || mc.getConnection() == null) {
                stop("離開世界或切換維度");
                return;
            }
            if (!mc.player.isAlive() || mc.player.isSpectator() || mc.player.isPassenger()) {
                stop("玩家狀態無法繼續");
                return;
            }
            if (state == State.PAUSED) return;
            if (!mc.isWindowActive() || mc.isPaused()) {
                pause("遊戲失去焦點或已開啟暫停選單");
                return;
            }
            if (state == State.OPENING && mc.player.containerMenu instanceof MerchantMenu menu && mc.gui.screen() instanceof MerchantScreen) {
                ownedMenu = menu;
            }
            boolean ownedScreen = ownedMenu != null && mc.player.containerMenu == ownedMenu && mc.gui.screen() instanceof MerchantScreen;
            if (mc.gui.screen() != null && !ownedScreen) {
                pause("開啟其他介面");
                return;
            }
            if ((state == State.SCAN || state == State.SELECTING || state == State.VERIFY) && !ownedScreen) {
                pause("交易視窗已關閉，重新檢查前先暫停");
                return;
            }
            if (ownedScreen && !ownedMenu.getCarried().isEmpty()) {
                pause("游標持有物品，請先整理背包");
                return;
            }
            if (delay > 0) { delay--; return; }
            switch (state) {
                case FIND -> findNext();
                case WALK -> walk();
                case OPENING -> waitForOffers();
                case SCAN -> scanOffer();
                case SELECTING -> waitForSelection();
                case VERIFY -> verifyTrade();
                case COOLDOWN -> state = State.FIND;
                default -> { }
            }
        } catch (Exception error) {
            LOG.error("VillagerTrader stopped safely after an error", error);
            stop("發生錯誤：" + error.getClass().getSimpleName() + "（詳見 latest.log）");
        }
    }

    private void findNext() {
        if (mc.player.containerMenu != mc.player.inventoryMenu) { pause("請先關閉容器"); return; }
        AABB bounds = new AABB(origin.x - RADIUS, origin.y - RADIUS, origin.z - RADIUS,
                               origin.x + RADIUS, origin.y + RADIUS, origin.z + RADIUS);
        target = world.getEntitiesOfClass(Villager.class, bounds, v ->
            v.isAlive() && !v.isBaby() && !visited.contains(v.getUUID())
                && v.position().distanceToSqr(origin) <= RADIUS * RADIUS && professionMatches(v))
            .stream().min(Comparator.comparingDouble(v -> v.distanceToSqr(mc.player))).orElse(null);
        if (target == null) {
            if (trades > passTrades && pass < 2) {
                pass++;
                passTrades = trades;
                visited.clear();
                missing.clear();
                return;
            }
            String reason = full ? "背包空間不足（需容納整批產物）"
                : !missing.isEmpty() ? "缺少交易材料：" + String.join(", ", missing)
                : soldOut > 0 ? "村民交易已售罄或尚未補貨"
                : matchingOffers == 0 ? "找不到可到達且符合選項的交易"
                : "本輪沒有更多可執行的交易";
            pause(reason);
            return;
        }
        visited.add(target.getUUID());
        villagersChecked++;
        navigator.start(target);
        state = State.WALK;
        overlay("前往村民 " + villagersChecked);
    }

    private boolean professionMatches(Villager v) {
        return "any".equals(selection.profession()) || v.getVillagerData().profession().unwrapKey()
            .map(k -> k.identifier().getPath().equals(selection.profession())).orElse(false);
    }

    private void walk() {
        if (target == null || !target.isAlive() || target.isRemoved()
            || target.position().distanceToSqr(origin) > RADIUS * RADIUS) { nextVillager(); return; }
        Navigator.Result result = navigator.tick();
        if (result == Navigator.Result.FAILED) { nextVillager(); return; }
        if (result != Navigator.Result.ARRIVED) return;
        navigator.stop();
        Vec3 hit = target.getEyePosition();
        if (!clearView(hit)) hit = target.getBoundingBox().getCenter();
        if (!clearView(hit) || mc.player.getEyePosition().distanceToSqr(hit) > 2.8 * 2.8) {
            nextVillager();
            return;
        }
        Vec3 delta = hit.subtract(mc.player.getEyePosition());
        mc.player.setYRot((float) Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0F);
        mc.player.setXRot((float) -Math.toDegrees(Math.atan2(delta.y, Math.sqrt(delta.x * delta.x + delta.z * delta.z))));
        mc.gameMode.interact(mc.player, target, new EntityHitResult(target, hit), InteractionHand.MAIN_HAND);
        state = State.OPENING;
        waited = 0;
    }

    private boolean clearView(Vec3 point) {
        return world.clip(new net.minecraft.world.level.ClipContext(mc.player.getEyePosition(), point,
            net.minecraft.world.level.ClipContext.Block.OUTLINE, net.minecraft.world.level.ClipContext.Fluid.ANY,
            mc.player)).getType() == net.minecraft.world.phys.HitResult.Type.MISS;
    }

    private void waitForOffers() {
        if (ownedMenu != null && !ownedMenu.getOffers().isEmpty()) {
            offerIndex = batches = 0;
            state = State.SCAN;
            delay = ACTION_DELAY;
            return;
        }
        if (++waited > GUI_TIMEOUT) nextVillager();
    }

    private MerchantOffer currentOffer() {
        if (ownedMenu == null || offerIndex < 0 || offerIndex >= ownedMenu.getOffers().size()) return null;
        return ownedMenu.getOffers().get(offerIndex);
    }

    private boolean matches(MerchantOffer offer) {
        return offer != null && TradeRules.matches(selection.buying(), selection.itemId(),
            itemId(offer.getCostA()), itemId(offer.getCostB()), itemId(offer.getResult()));
    }

    private void scanOffer() {
        MerchantOffer offer = currentOffer();
        if (offer == null || batches >= 100) { nextVillager(); return; }
        if (!matches(offer)) { offerIndex++; return; }
        matchingOffers++;
        if (offer.isOutOfStock()) { soldOut++; offerIndex++; return; }
        if (!canPay(offer)) {
            missing.add(itemId(offer.getCostA()));
            if (!offer.getCostB().isEmpty()) missing.add(itemId(offer.getCostB()));
            offerIndex++;
            return;
        }
        expectedOutput = offer.getResult().copy();
        outputPerTrade = expectedOutput.getCount();
        // The same local selection and packet order as vanilla MerchantScreen.
        beforeSelectState = ownedMenu.getStateId();
        ownedMenu.setSelectionHint(offerIndex);
        ownedMenu.tryMoveItems(offerIndex);
        mc.getConnection().send(new ServerboundSelectTradePacket(offerIndex));
        waited = 0;
        state = State.SELECTING;
        delay = ACTION_DELAY;
    }

    private boolean canPay(MerchantOffer offer) {
        int onlyA = 0, onlyB = 0, shared = 0;
        for (int i = 0; i < ownedMenu.slots.size(); i++) {
            if (i == 2) continue;
            ItemStack stack = ownedMenu.getSlot(i).getItem();
            if (stack.isEmpty()) continue;
            boolean a = offer.getItemCostA().test(stack);
            boolean b = offer.getItemCostB().map(cost -> cost.test(stack)).orElse(false);
            if (a && b) shared += stack.getCount();
            else if (a) onlyA += stack.getCount();
            else if (b) onlyB += stack.getCount();
        }
        return TradeRules.canPay(onlyA, onlyB, shared, offer.getCostA().getCount(), offer.getCostB().getCount());
    }

    private void waitForSelection() {
        MerchantOffer offer = currentOffer();
        if (!matches(offer) || offer.isOutOfStock()) { advanceOffer(); return; }
        ItemStack result = ownedMenu.getSlot(2).getItem();
        ItemStack a = ownedMenu.getSlot(0).getItem();
        ItemStack b = ownedMenu.getSlot(1).getItem();
        boolean valid = !result.isEmpty() && ItemStack.isSameItemSameComponents(result, expectedOutput)
            && result.getCount() == outputPerTrade && offer.satisfiedBy(a, b);
        waited++;
        // tryMoveItems predicts locally; prefer a server state update, but an unchanged
        // already-filled selection legitimately causes no new slot state packet.
        if (!valid || (ownedMenu.getStateId() == beforeSelectState && waited < 10)) {
            if (waited >= SYNC_TIMEOUT) {
                pause("交易選擇未同步，請確認材料與伺服器連線");
            }
            return;
        }
        batchLimit = TradeRules.batchOutput(a.getCount(), b.getCount(), offer.getCostA().getCount(),
            offer.getCostB().getCount(), offer.getMaxUses() - offer.getUses(), outputPerTrade);
        if (batchLimit <= 0) { advanceOffer(); return; }
        // Require room for the WHOLE quick-move batch AND every unspent payment
        // stack, so closing the vanilla merchant screen cannot spill returned inputs.
        if (!fitsBatchAndReturnedInputs(expectedOutput, batchLimit)) {
            full = true;
            advanceOffer();
            return;
        }
        beforeOutput = countHeld(expectedOutput);
        beforeClickState = ownedMenu.getStateId();
        beforeUses = offer.getUses();
        stableOutput = stableTicks = 0;
        // Ordinary vanilla quick-move, but no speculative local menu.clicked().
        // An empty prediction map makes the server send changed slots back rather
        // than silently accepting client prediction, so VERIFY can check real output.
        mc.getConnection().send(new ServerboundContainerClickPacket(ownedMenu.containerId,
            beforeClickState, (short) 2, (byte) 0, ContainerInput.QUICK_MOVE,
            new Int2ObjectOpenHashMap<>(), HashedStack.EMPTY));
        batches++;
        waited = 0;
        state = State.VERIFY;
        delay = ACTION_DELAY;
    }

    private boolean fitsBatchAndReturnedInputs(ItemStack result, long count) {
        ItemStack[] slots = new ItemStack[36];
        for (int i = 0; i < slots.length; i++) slots[i] = mc.player.getInventory().getItem(i).copy();
        // Conservative: reserve even the inputs that a successful trade consumes.
        for (int i = 0; i < 2; i++) {
            ItemStack payment = ownedMenu.getSlot(i).getItem();
            if (!insert(slots, payment, payment.getCount())) return false;
        }
        return insert(slots, result, count);
    }

    private static boolean insert(ItemStack[] slots, ItemStack item, long count) {
        if (item.isEmpty() || count <= 0) return true;
        for (ItemStack slot : slots) {
            if (!slot.isEmpty() && ItemStack.isSameItemSameComponents(slot, item)) {
                int move = (int) Math.min(count, Math.max(0, slot.getMaxStackSize() - slot.getCount()));
                slot.grow(move);
                count -= move;
            }
        }
        for (int i = 0; i < slots.length && count > 0; i++) {
            if (slots[i].isEmpty()) {
                int move = (int) Math.min(count, item.getMaxStackSize());
                slots[i] = item.copyWithCount(move);
                count -= move;
            }
        }
        return count == 0;
    }

    private void verifyTrade() {
        waited++;
        int gained = countHeld(expectedOutput) - beforeOutput;
        if (gained == stableOutput) stableTicks++;
        else { stableOutput = gained; stableTicks = 0; }
        // No local quick-move prediction was applied: these inventory changes are
        // server updates. Wait for the complete slot batch to settle before counting.
        if (ownedMenu.getStateId() != beforeClickState && gained > 0 && stableTicks >= 6) {
            if (gained > batchLimit || gained % Math.max(1, outputPerTrade) != 0) {
                pause("背包變更與交易不符，請手動檢查");
                return;
            }
            long completed = gained / Math.max(1, outputPerTrade);
            outputs += gained;
            trades += completed;
            // Vanilla normally increments the client's offer uses during click
            // prediction. Reconcile it only after the server output is observed.
            MerchantOffer offer = currentOffer();
            if (offer != null) {
                int expectedUses = Math.min(offer.getMaxUses(), beforeUses + (int) completed);
                while (offer.getUses() < expectedUses) offer.increaseUses();
            }
            overlay("交易完成 | 約 " + trades + " 次 | 產物 " + outputs);
            state = State.SCAN;
            delay = ACTION_DELAY;
            return;
        }
        if (waited >= SYNC_TIMEOUT) pause("等待交易同步逾時，請先確認背包；不會自動重複點擊");
    }

    private int countHeld(ItemStack wanted) {
        int count = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack stack = mc.player.getInventory().getItem(i);
            if (ItemStack.isSameItemSameComponents(stack, wanted)) count += stack.getCount();
        }
        if (ownedMenu != null) {
            for (int i = 0; i < 2; i++) {
                ItemStack stack = ownedMenu.getSlot(i).getItem();
                if (ItemStack.isSameItemSameComponents(stack, wanted)) count += stack.getCount();
            }
        }
        return count;
    }

    private void advanceOffer() {
        offerIndex++;
        state = State.SCAN;
        delay = ACTION_DELAY;
    }

    private void nextVillager() {
        navigator.stop();
        closeOwnedMenu();
        target = null;
        state = State.COOLDOWN;
        delay = 10;
    }

    private void closeOwnedMenu() {
        if (mc.player != null && mc.level == world && ownedMenu != null && mc.player.containerMenu == ownedMenu) {
            mc.player.closeContainer();
        }
        ownedMenu = null;
    }

    private static String itemId(ItemStack item) {
        return item.isEmpty() ? "" : BuiltInRegistries.ITEM.getKey(item.getItem()).toString();
    }

    private void chat(String text) {
        if (mc.player != null) mc.player.sendSystemMessage(Component.literal("[VillagerTrader] " + text));
    }

    private void overlay(String text) {
        if (mc.player != null) mc.player.sendOverlayMessage(Component.literal("[VillagerTrader] " + text));
    }
}

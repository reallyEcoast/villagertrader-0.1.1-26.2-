package dev.villagertrader;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TradeRulesTest {
    @Test void sellOnlyAcceptsEmeraldOutputs() {
        assertTrue(TradeRules.matches(false, "any", "minecraft:wheat", "", "minecraft:emerald"));
        assertFalse(TradeRules.matches(false, "any", "minecraft:emerald", "", "minecraft:bread"));
    }
    @Test void buyMustActuallySpendEmeralds() {
        assertTrue(TradeRules.matches(true, "any", "minecraft:emerald", "minecraft:book", "minecraft:enchanted_book"));
        assertTrue(TradeRules.matches(true, "any", "minecraft:book", "minecraft:emerald", "minecraft:enchanted_book"));
        assertFalse(TradeRules.matches(true, "any", "minecraft:wheat", "", "minecraft:bread"));
        assertFalse(TradeRules.matches(true, "any", "minecraft:emerald", "", "minecraft:emerald"));
    }
    @Test void itemFilterUsesCorrectSide() {
        assertTrue(TradeRules.matches(false, "minecraft:book", "minecraft:paper", "minecraft:book", "minecraft:emerald"));
        assertFalse(TradeRules.matches(false, "minecraft:wheat", "minecraft:paper", "", "minecraft:emerald"));
        assertTrue(TradeRules.matches(true, "minecraft:bread", "minecraft:emerald", "", "minecraft:bread"));
        assertFalse(TradeRules.matches(true, "minecraft:emerald", "minecraft:emerald", "", "minecraft:bread"));
    }
    @Test void duplicateInputCannotSpendSameStackTwice() {
        assertFalse(TradeRules.canPay(0, 0, 6, 4, 4));
        assertTrue(TradeRules.canPay(0, 0, 8, 4, 4));
    }
    @Test void componentPredicatesShareOnlyMatchingResources() {
        assertTrue(TradeRules.canPay(3, 2, 3, 4, 4));
        assertFalse(TradeRules.canPay(3, 2, 2, 4, 4));
        assertFalse(TradeRules.canPay(99, 0, 0, 4, 1));
    }
    @Test void singleInputAndAdjustedPrices() {
        assertTrue(TradeRules.canPay(24, 0, 0, 24, 0));
        assertFalse(TradeRules.canPay(23, 0, 0, 24, 0));
        assertFalse(TradeRules.canPay(-1, 0, 0, 1, 0));
    }
    @Test void batchCapacityRespectsUsesAndSecondInput() {
        assertEquals(24, TradeRules.batchOutput(64, 0, 2, 0, 12, 2));
        assertEquals(3, TradeRules.batchOutput(64, 3, 8, 1, 12, 1));
        assertEquals(0, TradeRules.batchOutput(64, 0, 0, 0, 12, 1));
        assertEquals(0, TradeRules.batchOutput(64, 64, 1, 1, 0, 1));
    }
}

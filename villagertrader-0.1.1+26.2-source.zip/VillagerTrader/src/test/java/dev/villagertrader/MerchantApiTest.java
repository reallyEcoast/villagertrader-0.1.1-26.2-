package dev.villagertrader;

import java.util.Optional;
import net.minecraft.SharedConstants;
import net.minecraft.server.Bootstrap;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.ItemCost;
import net.minecraft.world.item.trading.MerchantOffer;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MerchantApiTest {
    @BeforeAll static void bootstrap() {
        SharedConstants.tryDetectVersion();
        Bootstrap.bootStrap();
        net.minecraft.core.registries.BuiltInRegistries.DATA_COMPONENT_INITIALIZERS
            .build(net.minecraft.data.registries.VanillaRegistries.createLookup())
            .forEach(net.minecraft.core.component.DataComponentInitializers.PendingComponents::apply);
    }

    @Test void adjustedPriceIsNotBasePrice() {
        MerchantOffer offer = new MerchantOffer(new ItemCost(Items.WHEAT, 20),
            new ItemStack(Items.EMERALD), 12, 1, 0.05F);
        offer.setSpecialPriceDiff(-5);
        assertEquals(20, offer.getBaseCostA().getCount());
        assertEquals(15, offer.getCostA().getCount());
        assertFalse(offer.satisfiedBy(new ItemStack(Items.WHEAT, 14), ItemStack.EMPTY));
        assertTrue(offer.satisfiedBy(new ItemStack(Items.WHEAT, 15), ItemStack.EMPTY));
    }

    @Test void twoInputOffersRequireBothPayments() {
        MerchantOffer offer = new MerchantOffer(new ItemCost(Items.EMERALD, 5),
            Optional.of(new ItemCost(Items.BOOK)), new ItemStack(Items.ENCHANTED_BOOK), 12, 1, 0.05F);
        assertFalse(offer.satisfiedBy(new ItemStack(Items.EMERALD, 5), ItemStack.EMPTY));
        assertTrue(offer.satisfiedBy(new ItemStack(Items.EMERALD, 5), new ItemStack(Items.BOOK)));
        assertFalse(offer.getItemCostA().test(new ItemStack(Items.DIAMOND, 64)));
    }

    @Test void stockAndUseCounterMatchBatchLimits() {
        MerchantOffer offer = new MerchantOffer(new ItemCost(Items.STICK, 32),
            new ItemStack(Items.EMERALD), 2, 1, 0.05F);
        offer.increaseUses();
        assertFalse(offer.isOutOfStock());
        assertEquals(1, TradeRules.batchOutput(64, 0, offer.getCostA().getCount(), 0,
            offer.getMaxUses() - offer.getUses(), 1));
        offer.increaseUses();
        assertTrue(offer.isOutOfStock());
    }
}

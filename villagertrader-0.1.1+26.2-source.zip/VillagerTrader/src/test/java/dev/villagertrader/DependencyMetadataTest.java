package dev.villagertrader;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import net.fabricmc.loader.api.Version;
import net.fabricmc.loader.api.metadata.version.VersionPredicate;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DependencyMetadataTest {
    private static JsonObject metadata() throws Exception {
        try (var input = DependencyMetadataTest.class.getResourceAsStream("/fabric.mod.json")) {
            assertNotNull(input, "Packaged metadata must be present");
            return JsonParser.parseReader(new InputStreamReader(input, StandardCharsets.UTF_8)).getAsJsonObject();
        }
    }

    private static boolean accepts(String dependency, String installedVersion) throws Exception {
        String predicate = metadata().getAsJsonObject("depends").get(dependency).getAsString();
        return VersionPredicate.parse(predicate).test(Version.parse(installedVersion));
    }

    @Test void acceptsUserLoader0193() throws Exception {
        assertTrue(accepts("fabricloader", "0.19.3"));
    }

    @Test void acceptsUserApi0154For262() throws Exception {
        assertTrue(accepts("fabric-api", "0.154.0+26.2"));
    }

    @Test void keepsExactMinecraftTargetAndNewModVersion() throws Exception {
        assertTrue(accepts("minecraft", "26.2"));
        assertFalse(accepts("minecraft", "26.1"));
        assertFalse(accepts("minecraft", "26.3"));
        assertEquals("0.1.1+26.2", metadata().get("version").getAsString());
    }
}
